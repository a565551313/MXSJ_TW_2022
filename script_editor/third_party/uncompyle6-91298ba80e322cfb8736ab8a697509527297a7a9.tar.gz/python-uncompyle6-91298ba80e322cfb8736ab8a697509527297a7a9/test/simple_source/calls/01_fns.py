globals()
locals()
